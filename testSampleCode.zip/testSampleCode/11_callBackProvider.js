function callBackProvider(winFunc, looseFunc) {
    function makeRandomNumber(low, high) { // returns an integer in this range: low..high
        var random = Math.random();  // returns a real number between 0 and 1
        var diff = high - low + 1;  // determine the distance between the high and low. 
        return Math.floor(random * diff + low); // Math.floor truncates to integer
    }
    var random = makeRandomNumber(1, 100);

    if (random < 50) {
        looseFunc("Your number was only " + random);
    } else {
        if (random>75) {
            winFunc("$200");
        } else {
            winFunc ("$50");
        }
    }
}
