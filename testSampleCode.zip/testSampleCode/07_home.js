function home() {
    var myContent = document.createElement("div");
    myContent.innerHTML = "THIS IS MY HOME CONTENT";
    document.getElementById("content").appendChild(myContent);
}