function a ( ) {
    console.log("function a is running");
}

function b ( ) {
    console.log("function b is running");
}