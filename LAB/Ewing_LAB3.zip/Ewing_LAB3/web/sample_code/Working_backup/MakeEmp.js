"use strict";
function MakeEmp(theName, theTitle, theSalary, imgURL) {
    var empObj = document.createElement("div");
    
    // link the styling of empObj to all styles that start with ".emp"
    // which are in file emp.css
    empObj.classList.add("emp");
    
    // Public property made for name
    empObj.name = theName;
    
    // title is private
    var title = theTitle;
    
    // salary is private
    var salary = theSalary;
    
    // Display image on screen
    var empImg = document.createElement("img");
    empImg.src = imgURL;
    empObj.appendChild(empImg);
    
    // Create an info div where emp info can be displayed
    var empInfo = document.createElement("div");
    empObj.appendChild(empInfo);
    
    // private method display
    var display = function ( ) {
        empInfo.innerHTML = "Name: " + empObj.name + 
                "<br/> Title: " + title + "<br/> Price: " + formatCurrency(salary);
    };
    
    // private method display MAY NEED TO CHANGE
    function setTitle (newTitle) {
        title = newTitle;
        display(); // show updated property on the page
    };
    
    // setter method (public) for name
    empObj.setName = function(newName) {
        empObj.name = newName;
        display(); // show updated property on the page
    };
    
    // setter method (public) for salary
    empObj.changeSalary = function(changeRate) {
        var n = Number(changeRate);
        console.log("changing salary by this rate: " + n);
        salary = salary * (1 + n);
        display(); // show updated price on the page
    };
    
    // Create User interface for setting name
    var nameButton = document.createElement("button");
    nameButton.innerHTML = "Change name to: ";
    empObj.appendChild(nameButton);
    
    var newNameInput = document.createElement("input");
    empObj.appendChild(newNameInput);
    
    nameButton.onclick = function () {
        empObj.setName(newNameInput.value);
    };
    
    empObj.appendChild(document.createElement("br")); // new line
    
    // Create user interface for setting title
    var titleButton = document.createElement("button");
    titleButton.innerHTML = "Change title to: ";
    empObj.appendChild(titleButton);
    
    var newTitleInput = document.createElement("input");
    empObj.appendChild(newTitleInput);
    
    titleButton.onclick = function () {
        setTitle(newTitleInput.value);
    };
    
    empObj.appendChild(document.createElement("br")); // new line
    
    // Create user interface for modifiying the salary
    var salaryButton = document.createElement("button");
    salaryButton.innerHTML = "Scale salary to: ";
    empObj.appendChild(salaryButton);
    
    var salaryFactor = document.createElement("input");
    empObj.appendChild(salaryFactor);
    
    salaryButton.onclick = function () {
        empObj.changeSalary(salaryFactor.value);
    };
    
    // private function
    function formatCurrency(num) {
        return num.toLocaleString("en-US", {style: "currency", currency: "USD", minimumFractionDigits: 2});
    }
    
    display(); // show inital properties on the page
    return empObj;
}