These Web APIs were created to demonstrate (simple examples)
how to set an object into the session and then get that object back out.

Since there is no database access, there is no need to tunnel in and also
no need to add the MySQL database drivers (JAR file). 
