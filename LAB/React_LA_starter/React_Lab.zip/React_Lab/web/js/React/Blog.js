function Blog() {
    return (
        <div>
            <h3>Sample Blog Entry</h3>
            <p>
                Hey guys -- the Blog Component works !
            </p>
        </div>
    );
}