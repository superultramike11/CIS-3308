const UsersProp = () => { // now you don't need "props." in front of the properties.
    return <ComingSoon what="USERS" howFast="really fast" />;
}; 