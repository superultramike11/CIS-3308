function Fun() {
    return (
        <div className="comingSoon">
            <h3>Fun</h3>
            <p>
                hey --- the Fun is coming soon!
            </p>
        </div>
    );
}