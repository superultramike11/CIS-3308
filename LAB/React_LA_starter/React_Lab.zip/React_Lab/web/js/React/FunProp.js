const FunProp = () => { // now you don't need "props." in front of the properties.
    return <ComingSoon what="FUN" howFast="really really fun" />;
}; 